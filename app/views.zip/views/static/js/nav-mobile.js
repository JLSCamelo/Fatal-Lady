document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.getElementById("nav-toggle");
  var overlay = document.getElementById("mobile-menu-overlay");
  var closeBtn = document.getElementById("mobile-menu-close");

  if (!toggle || !overlay) {
    return;
  }

  function openMenu() {
    overlay.classList.add("is-open");
    overlay.setAttribute("aria-hidden", "false");
    toggle.setAttribute("aria-expanded", "true");
    document.body.classList.add("nav-open");

    // Foca no primeiro link do menu se existir
    var firstLink = overlay.querySelector("a");
    if (firstLink) {
      firstLink.focus({ preventScroll: true });
    }
  }

  function closeMenu() {
    overlay.classList.remove("is-open");
    overlay.setAttribute("aria-hidden", "true");
    toggle.setAttribute("aria-expanded", "false");
    document.body.classList.remove("nav-open");
    toggle.focus({ preventScroll: true });
  }

  toggle.addEventListener("click", function () {
    var isOpen = overlay.classList.contains("is-open");
    if (isOpen) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  if (closeBtn) {
    closeBtn.addEventListener("click", function () {
      closeMenu();
    });
  }

  // Fecha clicando fora do card do menu
  overlay.addEventListener("click", function (event) {
    if (event.target === overlay) {
      closeMenu();
    }
  });

  // Fecha com ESC
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      if (overlay.classList.contains("is-open")) {
        closeMenu();
      }
    }
  });

  // Fecha ao clicar em qualquer link do menu mobile
  overlay.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
      closeMenu();
    });
  });
});
